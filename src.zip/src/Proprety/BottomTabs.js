import { StyleSheet, Text, View } from 'react-native'
import React from 'react'
import {GrHomeRounded} from 'react-icons/gr'

const BottomTabs = () => {
    return (
        <View style={styles.tabContainer}>
            <View style={styles.button}>
            <Text style={styles.text}>A</Text>
            </View>
            <View style={styles.button}>
                <Text style={styles.text}>A</Text>
            </View>
            <View style={styles.button}>
                <Text style={styles.text}>A</Text>
            </View>
            <View style={styles.button}>
                <Text style={styles.text}>A</Text>
            </View>
            <View style={styles.button}>
                <Text style={styles.text}>A</Text>
            </View>
        </View>
    )
}

export default BottomTabs

const styles = StyleSheet.create({
    tabContainer: {
        width: '100%',
        height: 50,
        backgroundColor: 'white',
        position: 'absolute',
        bottom: 0,
        left: 0,
        flexDirection: 'row',
        elevation:3

    },
    button: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center'
    },
    text: {
        color: 'black'
    }
})