export default function Apilist() {
    let baseUrl = "http://192.168.0.16:8000"
    let apiList = {
        // 1 API TO LOGIN
        api_login: `${baseUrl}/api/login`,
    }

    return apiList
}