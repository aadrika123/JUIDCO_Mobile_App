import { StyleSheet, Text, View, ActivityIndicator } from 'react-native'
import { WebView } from 'react-native-webview';
import React, { useState, useEffect } from 'react'

const SafForm = () => {
    const [isLoading, setisLoading] = useState(false)

    // useEffect(() => {
    //     setisLoading(true)
    // }, [])

    return (
        <>
            {/* {isLoading && <ActivityIndicator
                color="blue"
                size="large"
            />} */}
            <WebView onLoad={() => setisLoading(false)} source={{ uri: 'http://192.168.0.160:3000/admin/safform/new/0' }} />
        </>
    )
}

export default SafForm

const styles = StyleSheet.create({})